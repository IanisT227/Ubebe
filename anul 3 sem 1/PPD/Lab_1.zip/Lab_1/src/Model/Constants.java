package Model;

public class Constants {
    public static final String AddOperation = "add";
    public static final String RemoveOperation = "remove";
    public static final String CheckOperation = "check";
}
