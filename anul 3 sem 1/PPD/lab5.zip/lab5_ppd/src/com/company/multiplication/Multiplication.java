package com.company.multiplication;

import com.company.model.Polynomial;

public interface Multiplication {
    Polynomial polynomialMultiplication(Polynomial first, Polynomial second);
}
