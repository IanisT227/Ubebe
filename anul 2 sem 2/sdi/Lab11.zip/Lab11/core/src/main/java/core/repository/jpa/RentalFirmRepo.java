package core.repository.jpa;

import core.domain.RentalFirm;

public interface RentalFirmRepo extends org.springframework.data.jpa.repository.JpaRepository<RentalFirm, Integer> {
}
